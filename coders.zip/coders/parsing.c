/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: airandri <airandri@student.42antananari    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/02 10:18:16 by airandri          #+#    #+#             */
/*   Updated: 2026/08/16 03:09:54 by airandri         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "codexion.h"

void	init_coder_id(t_coder *coder)
{
	t_coder	*tmp;
	int		i;
 
	if (!coder)
		return ;
	i = 1;
	tmp = coder;
	while (tmp)
	{
		tmp->id = i;
		tmp->dongle->id = i;
		tmp->dongle_hold = 0;
		tmp->compile_done = 0;
		tmp = tmp->next;
		i++;
	}
}

t_coder	*create_coder(void)
{
	t_coder		*new_coder;
	t_dongle	*new_dongle;

	new_dongle = (t_dongle *) malloc(sizeof(t_dongle));
	if (!new_dongle)
		return (NULL);
	new_coder = (t_coder *) malloc(sizeof(t_coder));
	if (!new_coder)
	{
		free(new_dongle);
		return (NULL);
	}
	new_coder->dongle = new_dongle;
	new_coder->prev = NULL;
	new_coder->next = NULL;
	return (new_coder);
}

void	add_coder(t_coder *coder)
{
	t_coder	*tmp;

	if (!coder)
		return ;
	tmp = coder;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = create_coder();
	if (tmp->next)
		tmp->next->prev = tmp;
}

void	linking_coder(t_all *all)
{
	int	i;
	t_coder	*last_coder;

	i = 0;
	while (i < (int)all->arguments->coders)
	{
		if (all->coder)
			add_coder(all->coder);
		else
			all->coder = create_coder();
		i++;
	}
	if (all->coder)
		all->coder->argument = all->arguments;
	init_coder_id(all->coder);
	last_coder = all->coder;
	while(last_coder->next)
		last_coder = last_coder->next;
	all->coder->prev = last_coder;
}

int	number_check(char *number)
{
	int	i;

	i = 0;
	while (number[i])
	{
		if (!is_digit(number[i]))
			return (0);
		i++;
	}
	if (atoi(number) <= 0 || 2147483647 < atoi(number))
		return (0);
	return (1);
}

void	assign_arg(char **init, t_args *arg)
{
	arg->coders = atoi(init[1]);
	arg->burnout = atoi(init[2]);
	arg->compile = atoi(init[3]);
	arg->debug = atoi(init[4]);
	arg->refactor = atoi(init[5]);
	arg->nb_compiles = atoi(init[6]);
	arg->dongle_cooldown = atoi(init[7]);
	if (!strcmp(init[8], "fifo"))
	{
		arg->scheduler.fifo = 1;
		arg->scheduler.edf = 0;
	}
	else if (!strcmp(init[8], "edf"))
	{
		arg->scheduler.fifo = 0;
		arg->scheduler.edf = 1;
	}
}

t_args	parsing(char **argv, t_args *arg)
{
	if (check_arg(argv))
	{
		assign_arg(argv, arg);
		arg->error = 0;
	}
	else
		arg->error = 1;
	return (*arg);
}

int	check_arg(char **arg)
{
	int	i;

	i = 1;
	while (i <= 7)
	{
		if (!number_check(arg[i]))
			return (0);
		i++;
	}
	if (strcmp(arg[8], "fifo") && strcmp(arg[8], "edf"))
		return (0);
	return (1);
}